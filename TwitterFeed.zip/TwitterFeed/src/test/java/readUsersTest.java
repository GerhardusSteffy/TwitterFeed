
import implementation.user;
import interfaces.Iuser;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import util.readUsers;
import java.io.BufferedReader;
import java.io.IOException;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class readUsersTest {

    private readUsers userReader;
    @Mock BufferedReader mmockBufferedReader;

    @Before
    public void setUp() {
        userReader = new readUsers();
    }

    @Test
    public void shouldFillListWithUsers() throws IOException {

        String line = "Ward follows Alan";

        userReader.buildListofUsers(line);

        assert (userReader.getListOfUsers() != null);
    }


    @Test(expected = IOException.class)
    public void shouldPrintErrorIfTextNotinRightFormat() throws IOException {
        String lineText = "Ward follows Alan Jeff ";

        userReader.buildListofUsers(lineText);
    }

    @Test(expected = IOException.class)
    public void shouldPrintErrorIfTextDoesNotHaveFollows() throws IOException {
        String lineText = "Ward  Alan, Jeff ";

        userReader.buildListofUsers(lineText);
    }

    @Test
    public void shouldAddfollowersAsuser() throws IOException {
        String line = "Ward follows Alan";

        userReader.buildListofUsers(line);

        user testUser = new user("Alan");
        assert (userReader.getListOfUsers().get(testUser) != null);
    }

    @Test
    public void shouldOnlyListTwoUsers() throws IOException {
        String lineText = "Ward follows Alan ";
        userReader.buildListofUsers(lineText);
        userReader.buildListofUsers(lineText);

        assert (userReader.getListOfUsers().size() == 2);

        user testUser = new user("Ward");
        assert (userReader.getListOfUsers().get(testUser) != null);

        user testUser2 = new user("Alan");
        assert (userReader.getListOfUsers().get(testUser2) != null);
    }

    @Test
    public void shouldBeTheSameObjectBasedOnName() {
        Iuser firstUser = new user("firstuser");
        Iuser secondUser = new user("firstuser");

        assert (firstUser.equals(secondUser));
        assert (firstUser.hashCode() == secondUser.hashCode());
    }

    @Test(expected = IOException.class)
    public void readerShouldThrowErrorForIncorrectFormat() throws IOException{
        BufferedReader bufferedReader = Mockito.mock(BufferedReader.class);
        Mockito.when(bufferedReader.readLine()).thenReturn("line1");
       userReader.readfile(bufferedReader);
    }



}
