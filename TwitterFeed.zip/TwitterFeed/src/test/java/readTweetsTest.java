
import implementation.user;
import interfaces.Iuser;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import util.readTweets;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;

public class readTweetsTest {

    private readTweets tweetsReader;
    private final ByteArrayOutputStream outContent  = new ByteArrayOutputStream();

    @Before
    public void setUp(){
        tweetsReader = new readTweets();
        System.setOut(new PrintStream(outContent));

    }

    @After
    public void cleanUp(){
        System.setOut(null);
    }
    @Test
    public void shouldAddTweetsForListeners() throws IOException{
        String lineText="Martin> Random numbers should not be generated with a method chosen at random.";

            Map<Iuser, Set<Iuser>> listOfUsers = new TreeMap<Iuser, Set<Iuser>>();
            listOfUsers.put(new user("Martin"),new HashSet<Iuser>());

        tweetsReader.buildListOfUserTweets(lineText,listOfUsers);

        assert (listOfUsers.get(new user("Martin")) != null);
    }

    @Test(expected = IOException.class)
    public void shouldPrintErrorIfTextNotinRightFormat() throws IOException{
        String lineText="Martin> Random numbers should not> be generated with a method chosen at random.";

        tweetsReader.buildListOfUserTweets(lineText,null);
    }

    @Test
    public void shouldOnlyListOneUserAndTwoTweets() throws IOException
    {
        String lineText="Martin> Random numbers should not be generated with a method chosen at random.";

        Map<Iuser, Set<Iuser>> listOfUsers = new TreeMap<Iuser, Set<Iuser>>();
        user martin = new user("Martin");
        listOfUsers.put(martin,new HashSet<Iuser>());

        tweetsReader.buildListOfUserTweets(lineText,listOfUsers);
        tweetsReader.buildListOfUserTweets(lineText,listOfUsers);

        assert (martin.getTweets().size()== 2);
        assert(listOfUsers.size() ==1);
    }


    @Test(expected = NullPointerException.class)
    public void shouldThrowPointerExceptionWhenNoUsersAreAdded() throws IOException
    {
        String lineText="Martin> Random numbers should not be generated with a method chosen at random.";
        tweetsReader.buildListOfUserTweets(lineText,null);
    }

    @Test
    public void readerShouldThrowErrorForIncorrectFormat() throws IOException{
        BufferedReader bufferedReader = Mockito.mock(BufferedReader.class);
        Mockito.when(bufferedReader.readLine()).thenReturn("Ward> There are only two hard things in Computer Science:" +
                " cache invalidation, naming things and off-by-1 errors. Alan> Random numbers should not be generated " +
                "with a method chosen at random. Alan> If you have a procedure with 10 parameters, you probably " +
                "missed some.",null);

        tweetsReader.readfile(bufferedReader,null);
        assert (outContent.toString().contains("Tweet length must be atmost 140 characters"));
    }
}
