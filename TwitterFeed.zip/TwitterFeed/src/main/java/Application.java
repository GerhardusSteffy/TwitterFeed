
import interfaces.Iuser;
import util.readTweets;
import util.readUsers;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

public class Application {
    public static void main(String[] args) {
        if (args.length == 2) {
            String userFile = args[0];
            String tweetFile = args[1];
            try {
                combineUsersWithTweets(userFile,tweetFile);

                System.out.print("Press Enter to exit");
                System.in.read();
            }
            catch (IOException ex)
            {
                System.out.println("An error has occured " + ex.getMessage());
            }
            catch (Exception e)
            {
                System.out.println("An unforseen error has occured:");
                e.printStackTrace();
            }
        } else {
            System.out.println("Please specify where the user and tweet files are");
        }
    }

    public static void combineUsersWithTweets(String userFile,String tweetFile) throws IOException{
        readUsers readUsers = new readUsers();
        readTweets readTweets = new readTweets();

        readUsers.buildUsersStructure(userFile);
        readTweets.buildTweets(tweetFile, readUsers.getListOfUsers());

        for(Map.Entry<Iuser, Set<Iuser>> tweeter : readUsers.getListOfUsers().entrySet()){
                System.out.println(tweeter.getKey().getUserName());
                for (String tweet : tweeter.getKey().getTweets()) {
                    System.out.println(tweet);
                }
            System.out.println();
        }
    }


}
