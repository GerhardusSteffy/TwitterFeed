package interfaces;

import implementation.user;


import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public interface Iuser {
    void setUsername(String name);
    String getUserName();
    ArrayList<String> getTweets();
    void addTweet(String message);
    void addFollower(Iuser Follower);
    Set<Iuser> getFollowers();

}
