package util;

import implementation.user;
import interfaces.Iuser;
import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public  class readTweets {
    private final Charset ENCODING = StandardCharsets.UTF_8;
    private final String SplitChar = ">";

    public void buildTweets(final String FileName,final Map<Iuser, Set<Iuser>> listOfUsers) throws IOException {
        Path path = Paths.get(FileName);

        try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)) {
            readfile(reader,listOfUsers);
        }
    }

    //Moving reader into separate method, allows for better unit testing
    public void readfile(final BufferedReader r,final Map<Iuser, Set<Iuser>> listOfUsers) throws IOException{
        String newLine = null;

        while ((newLine = r.readLine()) != null) {
            if(newLine.length() <= 140) {
                buildListOfUserTweets(newLine, listOfUsers);
            }
            else{
                System.out.println("Tweet length must be atmost 140 characters");
            }
        }
    }

    public void buildListOfUserTweets(final String textLine,final Map<Iuser, Set<Iuser>> listOfUsers) throws IOException {
        String[] splittedLine = textLine.split(SplitChar);

        if (splittedLine.length == 2) {
            user newUser = new user(splittedLine[0]);

            for (Map.Entry<Iuser, Set<Iuser>> listener : listOfUsers.entrySet()) {
                if (listener.getKey().equals(newUser)){
                    listener.getKey().addTweet("@" + listener.getKey().getUserName() + ":" + splittedLine[1]);
                }
                    for (Iuser follower : listener.getValue()) {
                        if (newUser.equals(follower)) {
                            listener.getKey().addTweet("@" + follower.getUserName() + ":" + splittedLine[1]);
                        }
                    }
                }
        } else {
            throw new IOException("Text not in right format");
        }
    }



}
