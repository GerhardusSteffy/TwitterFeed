package util;

import implementation.user;
import interfaces.Iuser;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

public class readUsers {

    private final Charset ENCODING = StandardCharsets.UTF_8;
    private Map<Iuser, Set<Iuser>> listOfUsers;
    private final String SplitChar = " ";

    public readUsers() {
        listOfUsers = new TreeMap<Iuser, Set<Iuser>>();
    }

    public void buildUsersStructure(final String fileName) throws IOException {

        Path path = Paths.get(fileName);
        try (BufferedReader reader = Files.newBufferedReader(path, ENCODING)) {
            readfile(reader);
        }
    }

    //Moving reader into separate method, allows for better unit testing
    public void readfile(BufferedReader r) throws IOException{
            String newLine = null;

        List<String> list = new ArrayList<>(10);

            while ((newLine = r.readLine()) != null) {
                buildListofUsers(newLine);
            }
    }

    public void buildListofUsers(String textLine) throws IOException {
        String[] splittedLine = textLine.split(SplitChar);
        Set<Iuser> users = new HashSet<>();

        if (splittedLine.length >= 3 && splittedLine[1].toLowerCase().equals("follows")) {
            Iuser follower = new user(splittedLine[0]);
            if (listOfUsers.containsKey(follower)) {
                users = listOfUsers.get(follower);
            }

            for (int i = 2; i < splittedLine.length; i++) {
                if (i != splittedLine.length - 1) {
                    if (!splittedLine[i].contains(",")) {
                        throw new IOException("Text not in right format");
                    } else {
                        splittedLine[i] = splittedLine[i].replaceAll(",", "");
                    }
                }
                Iuser user = new user(splittedLine[i]);
                if (!users.contains(user)) {
                    users.add(user);
                }
                if (!listOfUsers.containsKey(user)) {
                    listOfUsers.put(user, new HashSet<Iuser>());
                }
            }
            if (!listOfUsers.containsKey(follower)) {
                listOfUsers.put(follower, users);
            }
        } else {
            throw new IOException("Text not in right format");
        }
    }

    public Map<Iuser, Set<Iuser>> getListOfUsers() {
        return listOfUsers;
    }


}
