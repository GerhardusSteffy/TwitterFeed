package implementation;

import interfaces.Iuser;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class user implements Iuser,Comparable<user> {
    private String name;
    private ArrayList<String> tweets;
    private Set<Iuser> followers;

    public user(final String name){
        this.name = name;
        tweets = new ArrayList<String>();
        followers = new HashSet<Iuser>();
    }

    public void setUsername(String name){
        this.name = name;
    }

    @Override
    public String getUserName() {
        return name;
    }

    @Override
    public ArrayList<String> getTweets() {
        return tweets;
    }

    @Override
    public void addTweet(String message) {
        tweets.add(message);
    }

    @Override
    public Set<Iuser> getFollowers() {
            return followers;
    }

    @Override
    public void addFollower(final Iuser follower) {
        followers.add(follower);
    }


    @Override
    public int hashCode(){
        int result =0;
        char[] splitName = name.toCharArray();

        for(char nameChar : splitName){
            result += (int)nameChar;
        }

        return result;
    }

    @Override
    public boolean equals(Object other){

        if (other == null || (this.getClass() != other.getClass())){
            return false;
        }
        user otherUser = (user)other;
        return (this.hashCode() == otherUser.hashCode());
    }

    @Override
    public int compareTo(user o) {
        int nameDiff = name.compareToIgnoreCase(o.name);

            return nameDiff;

    }

    @Override
    public String toString(){
        return name;
    }

}
